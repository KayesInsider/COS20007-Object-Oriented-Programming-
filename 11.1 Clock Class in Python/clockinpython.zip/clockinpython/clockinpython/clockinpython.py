
class Counter:
    def __init__(self, name):
        self._name = name
        self._count = 0
    
    def increment(self):
        self._count += 1
    
    def reset(self):
        self._count = 0
    
    @property
    def name(self):
        return self._name
    
    @name.setter
    def name(self, value):
        self._name = value
    
    @property
    def ticks(self):
        return self._count


class Clock:
    def __init__(self):
        self._seconds = Counter("seconds")
        self._minutes = Counter("minutes")
        self._hours = Counter("hours")
    
    def ticks(self):
        self._seconds.increment()
        if self._seconds.ticks > 59:
            self._seconds.reset()
            self._minutes.increment()
            if self._minutes.ticks > 59:
                self._minutes.reset()
                self._hours.increment()
                if self._hours.ticks > 23:
                    self.reset()
    
    def reset(self):
        self._hours.reset()
        self._minutes.reset()
        self._seconds.reset()
    
    def get_time(self):
        sec = str(self._seconds.ticks).zfill(2)
        min = str(self._minutes.ticks).zfill(2)
        hours = str(self._hours.ticks).zfill(2)
        return hours + ":" + min + ":" + sec


clock = Clock()
for i in range(14400):
    clock.ticks()
    print(clock.get_time())
